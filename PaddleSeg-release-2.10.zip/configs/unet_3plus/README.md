# UNet 3+: A Full-Scale Connected UNet for Medical Image Segmentation

## Reference

> Huang H ,  Lin L ,  Tong R , et al. UNet 3+: A Full-Scale Connected UNet for Medical Image Segmentation[J]. ICASSP 2020 - 2020 IEEE International Conference on Acoustics, Speech and Signal Processing (ICASSP), 2020.
